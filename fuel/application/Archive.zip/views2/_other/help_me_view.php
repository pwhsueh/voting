<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>幫我提案</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="<?php echo site_url();?>">首頁</a></li>
                    <li>幫我提案</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="stepy-tab">
        <ul id="default-titles" class="stepy-titles clearfix">
            <li id="default-title-0" class="current-step">
                <div>步驟一</div><span> </span>
            </li>
            <li id="default-title-1" class="">
                <div>步驟二</div><span> </span>
            </li>
            <li id="default-title-2" class="">
                <div>步驟三</div><span> </span>
            </li>
        </ul>
    </div>
</div>
<div class="row">
    <div style="text-align:center;color:red">註：為了維護提案品質，初次提案時我們將針對您的Facebook檢視您的帳號，我們保證不會洩漏您任何資料，歡迎加入我們！</div>
    <div class="fb_login_btn"></div>
</div>