<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>幫我接案</h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li><a href="<?php echo site_url();?>">首頁</a></li>
                    <li>幫我接案</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="stepy-tab">
        <ul id="default-titles" class="stepy-titles clearfix">
            <li id="default-title-0">
                <div>步驟一</div><span> </span>
            </li>
            <li id="default-title-1" class="current-step">
                <div>步驟二</div><span> </span>
            </li>
            <li id="default-title-2" class="">
                <div>步驟三</div><span> </span>
            </li>
        </ul>
    </div>
</div>
<div class="row">
        
</div>