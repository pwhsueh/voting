<?php 
//$CI->load->module_view('app', '_install') 
?>

      <div class="container">
        <div class="row">
            <div class="col-lg-2 col-sm-2 sideBar">

            </div>
              <div class="col-lg-10 col-sm-10 sliderAd">
                <div class="row" style="margin: 3px 0 0 10px;">
                  <div class="fullwidthbanner-container main-slider" style="height:367px;">
                      <div class="fullwidthabnner">
                         <ul id="revolutionul" style="display:none;">
                             <!-- 1st slide -->
                             <li data-transition="fade" data-slotamount="8" data-masterspeed="700" data-delay="9400" data-thumb="">
                                 <div class="caption lfl slide_item_left"
                                      data-x="10"
                                      data-y="50"
                                      data-speed="400"
                                      data-start="1500"
                                      data-easing="easeOutBack">
                                     <img src="<?php echo $base_url?>assets/flat_img/banner/ban2.png" alt="Image 1">
                                 </div>
                                 <div class="caption lfr slide_title"
                                      data-x="670"
                                      data-y="100"
                                      data-speed="400"
                                      data-start="1000"
                                      data-easing="easeOutExpo">
                                      9iCase免費接外包
                                 </div>

                                 <div class="caption lfr slide_subtitle dark-text"
                                      data-x="670"
                                      data-y="190"
                                      data-speed="400"
                                      data-start="2000"
                                      data-easing="easeOutExpo">
                                     9icase外包專頁-視覺設計、程式設計、文字、兼職工作
                                 </div>
                                 <div class="caption lfr slide_desc"
                                      data-x="670"
                                      data-y="260"
                                      data-speed="400"
                                      data-start="2500"
                                      data-easing="easeOutExpo">
                                     最專業的外包粉絲團，你已經受夠了接案還要付錢嗎？ <br>
                                     9icase為您即時播報外包需求，外包網首選第一品牌9icase外包網<br>
                                 </div>
                                 <a class="caption lfr btn yellow slide_btn" href="https://www.facebook.com/9icase" target="_blank"
                                    data-x="670"
                                    data-y="350"
                                    data-speed="400"
                                    data-start="3500"
                                    data-easing="easeOutExpo">
                                     粉絲團
                                 </a>

                             </li>

                             <!-- 2nd slide  -->
                             <li data-transition="fade" data-slotamount="8" data-masterspeed="700" data-delay="9400" data-thumb="">
                                 <!-- THE MAIN IMAGE IN THE FIRST SLIDE -->
                                 <img src="<?php echo $base_url?>assets/flat_img/banner/banner_bg.jpg" alt="">
                                 <div class="caption lft slide_title"
                                      data-x="10"
                                      data-y="125"
                                      data-speed="400"
                                      data-start="1500"
                                      data-easing="easeOutExpo">
                                     9icase外包網
                                 </div>
                                 <div class="caption lft slide_subtitle dark-text"
                                      data-x="10"
                                      data-y="180"
                                      data-speed="400"
                                      data-start="2000"
                                      data-easing="easeOutExpo">
                                      誰說接案還要付費，9icase讓你接誰的案子通通免費
                                 </div>
                                 <div class="caption lft slide_desc dark-text"
                                      data-x="10"
                                      data-y="240"
                                      data-speed="400"
                                      data-start="2500"
                                      data-easing="easeOutExpo">
                                      今天要告訴大家一則令人振奮的消息！<br />
                                      還在煩惱貴森森的VIP費用，卻不一定接的到案子嗎？9icase聽到了！今天就幫你免費提案！<br />
                                      今天！就加入我們吧！
                                 </div>
                                 <a class="caption lft slide_btn btn red slide_item_left" href="http://9icase.com/case/help" target="_blank"
                                    data-x="10"
                                    data-y="360"
                                    data-speed="400"
                                    data-start="3000"
                                    data-easing="easeOutExpo">
                                     來提案吧！
                                 </a>
                                 <div class="caption lft start"
                                      data-x="640"
                                      data-y="55"
                                      data-speed="400"
                                      data-start="2000"
                                      data-easing="easeOutBack"  >
                                     <img src="<?php echo $base_url?>assets/flat_img/banner/man.png" alt="man">
                                 </div>
                                 <div class="caption lft slide_item_right"
                                      data-x="330"
                                      data-y="20"
                                      data-speed="500"
                                      data-start="5000"
                                      data-easing="easeOutBack">
                                     <img src="<?php echo $base_url?>assets/flat_img/banner/test_man.png" id="rev-hint2" alt="txt img">
                                 </div>

                             </li>
                         </ul>
                        <div class="tp-bannertimer tp-top"></div>
                      </div>
                  </div>
              </div>
              <div class="row text-show" style="margin: 3px 0 0 10px; background-color: #333; height:95px; padding: 5px 0 0 0; font-size: 24px; text-align:center;">
                <p style="color: #f37c6b; font-size:14px;">最新案件資訊</p>
                <ul class="text-effect-loop list-unstyled"></ul>
              </div>
            </div>
        </div>
      </div>

    <!--property start-->
    <div class="property gray-bg" style="margin-bottom:0px;padding-bottom:10px;padding-top:10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-6 text-center">
                    <img src="<?php echo $base_url?>assets/flat_img/property-img-1.png" alt="">
                </div>
                <div class="col-lg-6 col-sm-6">
                    <h1>9iCase給您最專業的外包平台</h1>
                    <p>抵制收費外包網，SOHO族要簽勞務報酬還要支付二代健保，實在是太瞎了，我們不要當外包網站的廉價勞工，我們要一個報價合理，品質又好的接外包網站，<a href="https://www.facebook.com/9icase 9icase" target="_blank">https://www.facebook.com/9icase</a> 9icase以免費、品質為考量，要以全民共審的發包機制來建立此平台，麻煩請先加入我們的粉絲團，並請期待我們即將推出的發包、接案平台！</p>
                    <a href="https://www.facebook.com/9icase" class="btn btn-purchase" target="_blank">粉絲團</a>
                </div>
            </div>
        </div>
    </div>
    <!--property end-->

      <div class="property gray-bg" style="margin-top:10px;padding-bottom:10px; padding-top:10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-sm-12 text-center">
                    <div class="fb-like-box" data-href="https://www.facebook.com/9icase" data-width="800" data-height="292" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true">
                    </div>
                </div>
            </div>
        </div>
    </div>

 