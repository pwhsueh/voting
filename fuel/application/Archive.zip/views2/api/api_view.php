<?php
	echo json_encode($json_data, JSON_HEX_APOS + JSON_HEX_AMP + JSON_HEX_TAG);